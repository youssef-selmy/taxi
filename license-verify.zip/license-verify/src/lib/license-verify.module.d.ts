export declare class LicenseVerifyModule {
}
