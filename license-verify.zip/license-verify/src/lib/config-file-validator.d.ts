import { ConfigModel } from './models/config.model';
export declare function getConfig(env: string): Promise<ConfigModel | null>;
