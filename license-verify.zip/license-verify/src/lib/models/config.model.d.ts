export declare class ConfigModel {
    purchaseCode?: string;
    backendMapsAPIKey?: string;
    adminPanelAPIKey?: string;
    firebaseProjectPrivateKey?: string;
    versionNumber?: number;
    companyLogo?: string;
    companyName?: string;
    taxi?: AppConfigInfo;
    shop?: AppConfigInfo;
    parking?: AppConfigInfo;
    mysqlHost?: string;
    mysqlPort?: number;
    mysqlUser?: string;
    mysqlPassword?: string;
    mysqlDatabase?: string;
    redisHost?: string;
    redisPort?: number;
    redisPassword?: string;
    redisDb?: number;
}
export declare class AppConfigInfo {
    logo?: string;
    name: string;
    color: AppColorScheme;
}
export declare enum AppColorScheme {
    Cobalt = "cobalt",
    CoralRed = "coralRed",
    EarthyGreen = "earthyGreen",
    SunburstYellow = "sunburstYellow",
    HyperPink = "hyperPink",
    ElectricIndigo = "electricIndigo",
    AutumnOrange = "autumnOrange",
    Noir = "noir"
}
