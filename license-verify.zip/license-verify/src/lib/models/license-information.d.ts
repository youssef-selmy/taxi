export declare class LicenseRemoteResponse {
    status: 'OK' | 'FAILED' | 'USED';
    message?: string;
    token?: string;
    data?: LicenseInformation;
    clients?: ClientData[];
}
export declare class ClientData {
    id: number;
    enabled: boolean;
    ip: string;
    port: number;
    token: string;
    purchaseId: number;
    firstVerifiedAt: string;
    lastVerifiedAt?: string;
}
export declare class LicenseInformation {
    token: string;
    buyerName: string;
    licenseType: LicenseType;
    purchasedAt: string;
    supportExpiry: string;
    connectedApps: AppType[];
    platformAddOns: PlatformAddOn[];
    benefits: string[];
    drawbacks: string[];
    availableUpgrades: {
        type: LicenseType;
        price: number;
        benefits: string[];
    }[];
}
export declare enum LicenseType {
    Regular = "Regular",
    Extended = "Extended",
    Bronze = "Bronze",
    Silver = "Silver",
    Gold = "Gold"
}
export declare enum AppType {
    Taxi = "Taxi",
    Shop = "Shop",
    Parking = "Parking"
}
export declare enum PlatformAddOn {
    FleetAddOn = "FleetAddOn"
}
