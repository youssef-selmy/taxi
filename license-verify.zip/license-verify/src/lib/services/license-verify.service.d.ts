import { HttpService } from '@nestjs/axios';
import { LicenseRemoteResponse } from '../models/license-information';
import { ConfigService } from './config.service';
export declare class LicenseVerifyService {
    private readonly httpService;
    private configService;
    licenseInformation?: LicenseRemoteResponse;
    constructor(httpService: HttpService, configService: ConfigService);
    verifyLicense(input?: {
        purchaseCode?: string;
        email?: string;
    }): Promise<LicenseRemoteResponse>;
    deactivteClient(input: {
        purchaseCode: string;
        ip: string;
    }): Promise<'OK' | 'FAILED'>;
}
