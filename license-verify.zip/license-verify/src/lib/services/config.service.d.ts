import { ConfigModel } from '../models/config.model';
export declare class ConfigService {
    constructor();
    getConfig(): Promise<ConfigModel>;
}
